/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_02.problema;

/**
 *
 * @author Dell
 */
public class PCFactory implements GameElementFactory{
    public Character createWarrior(){
        return new PCWarrior();
    }
    
    public Weapon createWeapon(){
        return new PCSword();
    }
    
}
