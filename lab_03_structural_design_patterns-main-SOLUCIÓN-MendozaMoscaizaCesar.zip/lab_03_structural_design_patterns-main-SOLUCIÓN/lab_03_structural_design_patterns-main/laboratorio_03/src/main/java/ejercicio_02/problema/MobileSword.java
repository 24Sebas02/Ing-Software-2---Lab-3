/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_02.problema;

/**
 *
 * @author Dell
 */
public class MobileSword extends Weapon{
    public MobileSword(){
        this.name = "Katana";
        this.platform = "Mobile";
    }
    
    @Override
    public void use(){
        System.out.println("Mobile Sword cuts swiftly");
    }
    
}
