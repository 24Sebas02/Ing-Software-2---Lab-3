/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_02.problema;

/**
 *
 * @author Dell
 */
public class MobileWarrior extends Character{
    public MobileWarrior(){
        this.name = "Samurai";
        this.platform = "Mobile";
    }
    
    @Override
    public void attack(){
        System.out.println("Mobile Warrior attacks with katana!");
    }
    
}
