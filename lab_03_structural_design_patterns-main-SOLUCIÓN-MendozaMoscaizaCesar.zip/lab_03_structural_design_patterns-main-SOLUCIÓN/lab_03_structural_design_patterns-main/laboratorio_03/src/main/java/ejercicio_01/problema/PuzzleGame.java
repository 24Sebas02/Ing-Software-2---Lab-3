/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_01.problema;

/**
 *
 * @author Dell
 */
public class PuzzleGame extends Game{
    public PuzzleGame(){
        this.name = "Brain Master";
        this.genre = "Puzzle";
    }
    
    @Override
    public void start(){
        System.out.println("Starting Puzzle Game: " + name);
    }
}
