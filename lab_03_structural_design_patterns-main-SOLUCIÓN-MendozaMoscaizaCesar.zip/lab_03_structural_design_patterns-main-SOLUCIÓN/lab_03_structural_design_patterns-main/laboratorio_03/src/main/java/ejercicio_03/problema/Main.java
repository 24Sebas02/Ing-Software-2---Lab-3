/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_03.problema;

/**
 *
 * @author jacks
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GameSession session = new GameSession();
        session.startSession();    // maxPlayers = 50, debug = false
        
        NetworkManager network = new NetworkManager();
        network.connect();         // debug = true (inconsistente!)
        
        DatabaseManager db = new DatabaseManager();
        db.saveData();       // databaseUrl diferente (inconsistente!)
    }
    
}
