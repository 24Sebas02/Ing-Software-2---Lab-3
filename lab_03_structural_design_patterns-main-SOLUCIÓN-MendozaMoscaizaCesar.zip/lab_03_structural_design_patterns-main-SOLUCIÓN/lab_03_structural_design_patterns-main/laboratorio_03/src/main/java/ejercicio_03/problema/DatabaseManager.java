package ejercicio_03.problema;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jacks
 */
public class DatabaseManager {

    public void saveData() {
        GameConfig config = GameConfig.getInstance();
        System.out.println("Saving data with debug mode = " + config.debugMode);
    }
}
