/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_03.problema;

/**
 *
 * @author jacks
 */
public class GameConfig {

    private static volatile GameConfig instance;
    public String databaseUrl;
    public boolean debugMode;
    public int maxPlayers;

    // Constructor público permite múltiples instancias
    public GameConfig() {
        this.databaseUrl = "jdbc:mysql://localhost:3306/gamedb";
        this.debugMode = false;
        this.maxPlayers = 100;
    }

    public static GameConfig getInstance(){
        if (instance == null){
            synchronized (GameConfig.class){
                if (instance == null){
                    instance = new GameConfig();
                }
            }
        }
        return instance;
    }
}
